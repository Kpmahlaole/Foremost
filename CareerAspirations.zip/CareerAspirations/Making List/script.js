$(document).on('pagebeforeshow', '#checklist', function() {
   $('input[type="checkbox"]').each(function() {
     ($(this).is(':checked')) ? $(this).parent().parent().addClass('checked'): $(this).parent().parent().addClass('not-checked');
   });
 });


 $(document).on('click', '.checkBoxLeft', function() {
   if ($(this).find('input[type="checkbox"]').is(':checked')) {
     $(this).removeClass('checked').addClass('not-checked');
     $(this).find('input[type="checkbox"]').attr('checked', false);
   } else {
     $(this).removeClass('not-checked').addClass('checked');
     $(this).find('input[type="checkbox"]').attr('checked', true);
   }

   //calculate percentage
   perc = 0;
   $("#theList input[type=checkbox]:checked").each(function(index) {
     perc += parseInt($(this).val());
   });

   if (perc < 15) {
     $("#progress").css('background', 'red');
   } else if (perc < 30) {
     $("#progress").css('background', 'orange');
   } else if (perc < 60) {
     $("#progress").css('background', 'yellow');
   } else {
     $("#progress").css('background', 'lime');
   }

   $("#progress").css("width", perc + "%");


 });
